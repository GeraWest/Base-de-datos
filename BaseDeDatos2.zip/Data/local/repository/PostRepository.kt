package mx.edu.utng.rgam.basededatos2.Data.local.repository

import kotlinx.coroutines.flow.Flow
import mx.edu.utng.rgam.basededatos2.Data.local.dao.PostDao
import mx.edu.utng.rgam.basededatos2.Data.local.entity.Post

class PostRepository(private val postDao: PostDao) {

    fun getAll(): Flow<List<Post>> = postDao.getAll()

    suspend fun insert(post: Post) = postDao.insert(post)

    suspend fun delete(post: Post) = postDao.delete(post)
}
