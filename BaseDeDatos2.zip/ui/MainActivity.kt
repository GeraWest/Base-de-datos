package mx.edu.utng.rgam.basededatos2.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import mx.edu.utng.rgam.basededatos2.Data.local.database.AppDatabase
import mx.edu.utng.rgam.basededatos2.Data.local.repository.PostRepository
import mx.edu.utng.rgam.basededatos2.ui.screens.PostScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val dao = AppDatabase.getInstance(this).postDao()
        val repository = PostRepository(dao)

        setContent {
            MaterialTheme {
                PostScreen(repository)
            }
        }
    }
}
