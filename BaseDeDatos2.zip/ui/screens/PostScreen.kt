package mx.edu.utng.rgam.basededatos2.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import mx.edu.utng.rgam.basededatos2.Data.local.entity.Post
import mx.edu.utng.rgam.basededatos2.Data.local.repository.PostRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostScreen(repository: PostRepository) {
    val scope = rememberCoroutineScope()
    var text by remember { mutableStateOf("") }
    val posts by repository.getAll().collectAsState(initial = emptyList())

    Scaffold(
        topBar = { TopAppBar(title = { Text("CRUD con Room") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Nuevo Post") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(
                onClick = {
                    if (text.isNotBlank()) {
                        scope.launch {
                            repository.insert(Post(content = text))
                            text = ""
                        }
                    }
                },
                modifier = Modifier.padding(top = 8.dp)
            ) {
                Text("Agregar")
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(posts) { post ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .padding(12.dp)
                                .fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(post.content)
                            TextButton(onClick = {
                                scope.launch { repository.delete(post) }
                            }) {
                                Text("Eliminar")
                            }
                        }
                    }
                }
            }
        }
    }
}
