package mx.edu.utng.rgam.basededatos2.ui.theme.viewmode

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import mx.edu.utng.rgam.basededatos2.Data.local.entity.Post
import mx.edu.utng.rgam.basededatos2.Data.local.repository.PostRepository

class PostViewMode(private val repository: PostRepository) : ViewModel() {

    val posts: StateFlow<List<Post>> = repository.getAll().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun insert(content: String) {
        viewModelScope.launch {
            repository.insert(Post(content = content))
        }
    }

    fun delete(post: Post) {
        viewModelScope.launch {
            repository.delete(post)
        }
    }
}
